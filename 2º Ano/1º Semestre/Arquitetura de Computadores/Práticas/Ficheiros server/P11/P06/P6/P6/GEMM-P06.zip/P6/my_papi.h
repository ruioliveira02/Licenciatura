
#include "papi.h"


int MYPAPI_init (const int , const int , const int , int *); 

int MYPAPI_start (void);

int MYPAPI_stop ();

void MYPAPI_output (void);
